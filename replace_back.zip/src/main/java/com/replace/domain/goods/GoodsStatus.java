package com.replace.domain.goods;

public enum GoodsStatus {
    AVAILABLE, SOLD_OUT
}
