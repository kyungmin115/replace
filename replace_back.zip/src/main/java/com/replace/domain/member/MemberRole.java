package com.replace.domain.member;

public enum MemberRole {
    USER, ADMIN;
}