package com.replace.dto.performance;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@RequiredArgsConstructor
public class FacilityDTO {

    private String mt10id;
    private String fcltynm;
    private String telno;
    private String adres;
    private String la;
    private String lo;

}
