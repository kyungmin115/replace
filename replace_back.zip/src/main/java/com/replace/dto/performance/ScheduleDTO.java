package com.replace.dto.performance;

import lombok.Data;

@Data
public class ScheduleDTO {

    private String day;
    private String startDay;
    private String endDay;
    private String time;
}
