package com.replace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReplaceApplicationTests {

    @Test
    void contextLoads() {
    }

}
